#pragma once

#include <evpp/exp.h>
#include "evnsq_export.h"
#include "consumer.h"

#ifdef H_OS_WINDOWS
#pragma comment(lib, "evnsq_static.lib")
#endif

